export default function Page() {
  return <div className="text-xl font-bold">Coming Soon</div>
}
